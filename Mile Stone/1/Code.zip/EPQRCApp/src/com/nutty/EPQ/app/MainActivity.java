package com.nutty.EPQ.app;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends ActionBarActivity implements OnTouchListener {

	Button prefs, connect;
	public static Button front;
	public static Button back;
	public static Button left;
	public static Button right;
	public static TextView Status, instructions;
	public static int gofront, goside, command;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		init();
		OnClick();

	}


	private void init() {
		gofront = 1;
		goside = 1;
		command = 0;
		prefs = (Button) findViewById(R.id.Main_prefs);
		connect = (Button) findViewById(R.id.Main_Connect);
		
		front = (Button) findViewById(R.id.main_Front);
		back = (Button) findViewById(R.id.Main_Back);
		left = (Button) findViewById(R.id.Main_Left);
		right = (Button) findViewById(R.id.Main_Right);
		
		front.setOnTouchListener(this);
		back.setOnTouchListener(this);
		left.setOnTouchListener(this);
		right.setOnTouchListener(this);
		
		Status = (TextView) findViewById(R.id.Main_Status);
		instructions = (TextView) findViewById(R.id.Main_Instructions);
		
	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		return UpdateMovment.OnTouch(v, event);
	}
	
	private void OnClick() {
		prefs.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Open Prefs AND DISSCONECT
				
			}
		});
		
		connect.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				AsyncTaskRunner runner = new AsyncTaskRunner();
				runner.execute();
				// TODO Connect or diss, make global var to say if conected or not
				
			}
		});
		
	}

}
