package com.nutty.EPQ.app;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OptionalDataException;
import java.net.Socket;
import java.net.UnknownHostException;

import android.os.AsyncTask;

public class AsyncTaskRunner extends AsyncTask<String, String, String> {
	private String Strin;
	private int[] Arrayout = { 0, 0, 1 };

	@SuppressWarnings({ "resource" })
	@Override
	protected String doInBackground(String... params) {
		System.out.println("1111");
		Boolean keepgoing = true;
		String hostname = "192.168.1.105";
		// TODO get hostname from prefs
		ObjectInputStream in = null;
		ObjectOutputStream out = null;
		Socket Server = null;
		String Message;

		try {
			Server = new Socket(hostname, 40506);
			out = new ObjectOutputStream(Server.getOutputStream());
			in = new ObjectInputStream(Server.getInputStream());
			Message = "Connected";
			System.out.println("dn");
		} catch (UnknownHostException e) {
			System.out.println("er");
			e.printStackTrace();
			Message = "error UnknowHost";
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("er");
			Message = "error IOExecption " + e.toString();
		}
		publishProgress(Message, "0");
		
		if (Message != "Connected") {
			return "1";
		}

		while (keepgoing) {

			try {
				Thread.sleep((1 / 16) * 1000);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
			Arrayout = Connections.Makeout(Arrayout);
			int dbg = 0;
			if (Arrayout[0] == 0) {
				try {
					int[] Arrayout1 = {MainActivity.command, MainActivity.gofront, MainActivity.goside};
					publishProgress(Integer.toString(Arrayout1[1]), "0");
					publishProgress(Integer.toString(Arrayout1[2]), "1");
					out.writeObject(Arrayout1);
					out.flush();
				} catch (IOException e) {
					e.printStackTrace();
					keepgoing = false;
					publishProgress("ERROR writing to server: " + e.toString(), "0");
				}
			}else{
				keepgoing = false;
			}
		}
		
		
		try {
			in.close();
			out.close();
			Server.close();
			publishProgress("Dissconected");
		} catch (IOException e) {
			e.printStackTrace();
			publishProgress("Error Dissconecting:" + e.toString());
		}
		

		return null;
	}

	protected void onPostExecute(String result) {
		// execution of result of Long time consuming operation
	}

	@Override
	protected void onPreExecute() {
		// Things to be done before execution of long running operation. For
		// example showing ProgessDialog
	}

	@Override
	protected void onProgressUpdate(String... arg) {
		if(arg[1] == "0"){
			MainActivity.Status.setText(arg[0]);
			MainActivity.instructions.setText(Integer.toString(Arrayout[1]));
			System.out.println(arg[0]);
		}else if(arg[1] == "1"){
			MainActivity.instructions.setText(Integer.toString(Arrayout[1]));
		}
	}
}