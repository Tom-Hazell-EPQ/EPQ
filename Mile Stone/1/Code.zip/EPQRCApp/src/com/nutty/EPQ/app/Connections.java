package com.nutty.EPQ.app;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class Connections {
	public static String setup(ObjectInputStream in, ObjectOutputStream out,
			Socket Server, String hostname) {

		try {
			Server = new Socket(hostname, 7);

			in = new ObjectInputStream(Server.getInputStream());

			out = new ObjectOutputStream(Server.getOutputStream());

		} catch (UnknownHostException e) {

			e.printStackTrace();
			return "error UnknowHost";
		} catch (IOException e) {
			e.printStackTrace();
			return "error IOExecption";
		}
		return "Connected";
	}

	public static String DC(ObjectInputStream in, ObjectOutputStream out,
			Socket Server) {
		try {
			in.close();
			out.close();
			Server.close();

		} catch (IOException e) {
			e.printStackTrace();
			return "error" + e.toString();
		}

		return "Dissconected";
	}

	public static int[] Makeout(int[] Array) {
		Array[0] = MainActivity.command; 
		Array[1] = MainActivity.gofront; 
		Array[2] = MainActivity.goside; 
		return Array;
	}

}
