package com.nutty.EPQ.server;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.UnknownHostException;

public class Connections_server {

	public static void Create_socket(InetAddress addr,
			ServerSocket serverSocket, String listen_address) {

		try {
			addr = InetAddress.getByName(listen_address);
			serverSocket = new ServerSocket(40506, 0, addr);
		} catch (UnknownHostException e) {
			System.err.println("Could not find host:" + listen_address);
			System.exit(1);
			e.printStackTrace();

		} catch (IOException e) {
			System.err.println("Could not listen on port: 10008.");
			System.exit(1);

			e.printStackTrace();
		}

		System.out.println("Connection Socket Created");

	}

	public static void Accept_conections(ServerSocket serverSocket) {

		try {
			while (true) {
				System.out.println("Waiting for Connection");
				new Main_Server(serverSocket.accept());
				// Accepts all new connections
			}
		} catch (IOException e) {
			System.err.println("Accept failed.");
			System.exit(1);
		} finally {
			try {
				serverSocket.close();
				// close server
			} catch (IOException e) {
				System.err.println("Could not close port: 10008.");
				System.exit(1);
			}
		}

	}
}
