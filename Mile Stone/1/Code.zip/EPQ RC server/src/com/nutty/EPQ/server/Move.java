package com.nutty.EPQ.server;

public class Move {
	public static void doit(int[] Array){
		System.out.println(Array[0] + ":" + Array[1] + ":" + Array[2]);
		
		
	}
	
	
	public static void what(){
		System.out.println("what do you mean, this could be us but you playing?");
	}
}
