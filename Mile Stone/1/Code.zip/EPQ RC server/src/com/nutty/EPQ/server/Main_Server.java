package com.nutty.EPQ.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

public class Main_Server extends Thread {

	protected Socket clientSocket;
	int out1 = 1;

	public static void main(String[] args) throws IOException {
		BufferedReader In;
		InetAddress addr = null;
		ServerSocket serverSocket = null;
		String listen_address;

		System.out
				.println("make sure the raspberry pi is connected to network and use ifconfig in terminal to find the IP addres of the device.");
		System.out
				.println("enter the IP of the raspberry pi on the network you wish to control this from");

		In = new BufferedReader(new InputStreamReader(System.in));
		listen_address = new String(In.readLine());

		try {
			addr = InetAddress.getByName(listen_address);
			serverSocket = new ServerSocket(40506, 0, addr);
			In.close();
		} catch (UnknownHostException e) {
			System.out.println("Could not find host:" + listen_address);
			System.exit(1);
			e.printStackTrace();

		} catch (IOException e) {
			System.out.println("Could not listen on port: 10008.");
			System.exit(1);

			e.printStackTrace();
		}

		System.out.println("Connection Socket Created");

		try {
			while (true) {
				System.out.println("Waiting for Connection");
				new Main_Server(serverSocket.accept());
				// Accepts all new connections
			}
		} catch (IOException e) {
			System.out.println("Accept failed.");
			System.exit(1);
		} finally {
			try {
				serverSocket.close();
				// close server
			} catch (IOException e) {
				System.out.println("Could not close port: 10008.");
				System.exit(1);
			}
		}

		In.close();
	}

	Main_Server(Socket clientSoc) {
		clientSocket = clientSoc;
		start();
		// starts thread for this client
	}

	public void run() {
		System.out.println("New Communication Thread Started");

		ObjectInputStream in = null;
		ObjectOutputStream out = null;
		try {
			in = new ObjectInputStream(clientSocket.getInputStream());
			out = new ObjectOutputStream(clientSocket.getOutputStream());

		} catch (IOException e1) {
			System.out.println("Problem with Communication Server "
					+ e1.toString());
			
			try {
				out.close();
				in.close();
				clientSocket.close();

			} catch (IOException e) {
				e.printStackTrace();
			}
			System.exit(1);
		}


		// initilise and set up PrintWriter and Buffredreader
		boolean keepgoin = true;
		while (keepgoin) {
			int[] Arrayin = { 0, 0, 0 };
			try {
				Arrayin = (int[]) in.readObject();
				if(Arrayin[0] == 1){
				Move.doit(Arrayin);
				}else{
					keepgoin = false;
				}
			} catch (ClassNotFoundException e) {
				keepgoin = false;
				System.out.println("error:" + e.toString());
			} catch (IOException e) {
				keepgoin = false;
				System.out.println("error:" + e.toString());
			}
			

		}

		try {

			// Dissconect
			out.close();
			in.close();
			clientSocket.close();
		} catch (IOException e) {
			
		}
	}
}
